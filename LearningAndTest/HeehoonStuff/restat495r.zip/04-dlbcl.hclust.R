library(survival)

##################################################
### read in data

dlbcl.data <- as.matrix(read.table("dlbcl_expressiondata.csv",sep=","))
dlbcl.surv <- as.matrix(read.table("dlbcl_survdata.csv",sep=","))
dim(dlbcl.data)
dlbcl.surv
dlbcl.time <- dlbcl.surv[,1]
dlbcl.cens <- dlbcl.surv[,2]

# divide data into training/test sets
set.seed(538)
train.index <- sample(c(1:240),120)
dlbcl.train.data <- dlbcl.data[,train.index]
dlbcl.train.time <- dlbcl.surv[train.index,1]
dlbcl.train.cens <- dlbcl.surv[train.index,2]

dlbcl.test.data <- dlbcl.data[,-train.index]
dlbcl.test.time <- dlbcl.surv[-train.index,1]
dlbcl.test.cens <- dlbcl.surv[-train.index,2]

### hierarchical clustering

dim(t(dlbcl.train.data)) # cluster on rows

# distance matrix
dlbcl.dist <- dist(t(dlbcl.train.data)) # default is euclidean

# linkage
dlbcl.clust <- hclust(dlbcl.dist,) # default is complete
plot(dlbcl.clust)  # resultant dendrogram

dlbcl.clust <- hclust(dlbcl.dist,method="ward")
plot(dlbcl.clust)  # resultant dendrogram

#postscript("dlbcl.dendrogram.ps")
#  plot(dlbcl.clust)  
#dev.off()

### HEATMAP: CAN TAKE A LONG TIME #####
#postscript("dlbcl.heatmap.ps",height=10,width=10)
heatmap(t(dlbcl.train.data),Rowv=as.dendrogram(dlbcl.clust),Colv=NA)
#dev.off()
#system("ps2pdf dlbcl.heatmap.ps dlbcl.heatmap.pdf")
#system("rm dlbcl.heatmap.ps")
###########################

cutree(dlbcl.clust,k=2)
cutree(dlbcl.clust,k=3)
dlbcl.2group <- cutree(dlbcl.clust,k=2) - 1
dlbcl.2group


# check whether clustering approach successfully
# distinguished between high-risk / low-risk groups
# in training data set

survdiff(Surv(dlbcl.train.time,dlbcl.train.cens)~c(dlbcl.2group))



###### obtain Cox model (w/ coefficient vector)

group1 <- dlbcl.train.data[,dlbcl.2group==0]
group2 <- dlbcl.train.data[,dlbcl.2group==1]

twosample.ttest <- NA
for(i in 1:nrow(dlbcl.data)) {
  twosample.ttest[i] <- t.test(group1[i,],group2[i,],var.equal=T)$p.value 
}
hist(twosample.ttest)
sum(twosample.ttest < 1e-10)
which(twosample.ttest < 1e-10)
hclust.coef <- which(twosample.ttest < 1e-10)


hclust.res <- coxph(Surv(dlbcl.train.time,dlbcl.train.cens)~t(dlbcl.train.data[hclust.coef,]))
summary(hclust.res)
# need to create a coefficient vector (length=number of markers,
#    all zeros expect for selected markers
hclust.fit.beta <- rep(0,nrow(dlbcl.train.data))
for(i in 1:length(hclust.coef)) {
  hclust.fit.beta[hclust.coef[i]] <- hclust.res$coef[[i]]
}

